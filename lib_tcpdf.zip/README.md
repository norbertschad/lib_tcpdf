TCPDF Library for Joomla! 3.x
=============================

TCPDF Library helps applications to generate PDF files for CMS Joomla! 3.x.

Library Version: 6.2.12

## Installation

Just download and install.

## Usage

Add this code to head of file to import TCPDF class:

jimport('tcpdf.tcpdf');

* [TCPDF Examples](http://www.tcpdf.org/examples.php)

## Authors

* Bruno Batista

## License

Licensed under the terms of the MIT license.

## Bugs/Requests

* You can [report a bug or request a feature here](http://github.com/joomlapro/lib_tcpdf/issues)